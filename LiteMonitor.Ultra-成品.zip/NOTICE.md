# NOTICE · 与上游 LiteMonitor 的能力差异

本项目 **LiteMonitor.Ultra** 基于 [Diorser/LiteMonitor](https://github.com/Diorser/LiteMonitor)（MIT 协议）派生，为**非官方二次开发版本**，与原作者 **Diorser** 无关联。

本文说明本项目相对上游新增 / 变更的能力，便于使用者与贡献者快速了解差异。

---

## 一、定位

| 项 | 上游 LiteMonitor | 本项目 LiteMonitor.Ultra |
|---|---|---|
| 作者 | Diorser | 小吴同学电气设计（t84RT） |
| 官方主页 | [litemonitor.cn](https://litemonitor.cn) | [github.com/t84RT](https://github.com/t84RT) |
| 核心 | 轻量桌面/任务栏硬件监控 | 同左 + 叠加 Ultra 运行时（不破坏上游核心） |
| UI 形态 | 竖屏 / 横条 | 新增 12 种形态（见下） |

## 二、新增能力（Ultra 运行时）

- **12 种 UI 形态**：紧凑单条、双列信息表、卡片网格、环形仪表盘、迷你折线、终端 HUD、玻璃拟态、点阵电平、AI 新闻跑马灯、极简纯文本、资讯播报条、原版竖/横屏。
- **10 套内置主题**（`resources/ultra_themes/`）+ 跟随系统 / 定时切换。
- **AI 每日热榜**：自动抓取 `tophub.today/c/ai`，任务栏嵌入 / 面板叠加 / 独立窗口三种播报。
- **热榜导航（214 站点）**：内置「今日热榜」同类站点清单，搜索 / A–E 分组 / 一键打开 / 复制链接。
- **工具箱 8 分页**：系统概览、进程 TOP、磁盘网络、文本工具、截图取色、备份、快捷启动等。
- **全局热键 7 组**：`Ctrl+Alt` + V/T/U/N/B/H/A。
- **兼容性自检**：DPI、多屏、字体回退、硬件降级、性能分档、虚拟机识别。

## 三、对上游核心的改动（刻意最小化）

Ultra 运行时通过 `UltraRuntime.Render` 在 `UIController.Render` 首行分派，**仅 7 处接入点**改动上游代码（入口注册、菜单注入、渲染分派等），上游其余源码保持不变，便于跟随上游升级。

## 四、暂未引入的能力（参考项目 LiteMonitorPlus 有、本项目暂缓）

> 以下为「参考方向」，非缺陷。如需可在后续版本引入。

- GPU 材质渲染（DirectX 11 玻璃材质 / 实时桌面背景）。
- 主题工作室 / 主题市场 / 插件市场（远程索引一键安装）。
- 规则化报警（条件 + 持续时间 + 动作）、情景模式（配置档案一键切换）。
- 多显卡分卡监控、趋势统计长期历史、诊断中心导出诊断包。
- Web 监控面板口令加密（DPAPI）。

## 五、许可

本项目与上游均为 **MIT License**。使用、修改、分发请**保留原作者 Diorser 与二次开发者（小吴同学电气设计 / t84RT）的署名**。完整许可证见 [LICENSE](./LICENSE)，架构说明见 [docs/](./docs/architecture.md)。
