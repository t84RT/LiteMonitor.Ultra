# LiteMonitor Ultra · 完整开发文档

> 基于 [Diorser/LiteMonitor](https://github.com/Diorser/LiteMonitor) v1.3.7（MIT）的衍生版本。
> 保留原作者全部署名与许可；本仓库新增部分同样以 MIT 开源。
> 目标：**更多 UI 形态切换 + 适配更多电脑 + 更多实用工具 + 每日 AI 热榜**。

---

## 0. 一分钟上手

```bat
build-ultra.bat
:: 或
dotnet build -c Release
:: 输出 bin/Release/net8.0-windows/LiteMonitor.exe（绿色免安装，直接双击）
```

托盘/悬浮窗右键 → 菜单最上方 **★ Ultra 增强**。

![悬浮监控条](./screenshots/01-monitor-bar.png)
*悬浮监控条（CompactBar 形态）：实时显示 CPU / GPU / 温度 / 内存 / 上下行速率，颜色按阈值报警。*

![原版右键菜单](./screenshots/02-base-menu.png)
*原版 LiteMonitor（Diorser）托盘右键菜单。*

![Ultra 增强菜单](./screenshots/03-ultra-menu.png)
*二次开发新增的「★ Ultra 增强」菜单：12 种 UI 形态、主题、AI 热榜、热榜导航（214 站点）、关于（作者信息）等入口。*

| 热键 | 动作 |
|---|---|
| `Ctrl+Alt+V` | 顺序切换 12 种 UI 形态 |
| `Ctrl+Alt+T` | 顺序切换 10 套 Ultra 主题 |
| `Ctrl+Alt+U` | 打开工具箱 |
| `Ctrl+Alt+N` | 打开 AI 每日热榜 |
| `Ctrl+Alt+B` | 开关任务栏 / 导航栏资讯播报 |
| `Ctrl+Alt+H` | 打开热榜导航（内置 214 个同类聚合站点） |
| `Ctrl+Alt+A` | 打开「关于 LiteMonitor.Ultra」（原作者 Diorser + 二次开发者 t84RT 信息） |

---

## 1. 设计参考：集合了谁的优点

| 参考对象 | 借鉴的设计 / 能力 | 落地位置 |
|---|---|---|
| **LiteMonitor 原版** | 主题系统 v2、横/竖/任务栏三态、三色报警、鼠标穿透、靠边隐藏、插件系统、网页版监控 | 全部保留，`Classic` 视图直接复用原渲染器 |
| **TrafficMonitor**（zhongyang219, 44k★） | 任务栏嵌入、skin.ini 皮肤包、主窗口/任务栏样式分离、每项独立颜色、透明键解决 Win11 白任务栏 | `CompactBarView`、`MinimalTextView`、Ultra 主题 JSON、菜单分组 |
| **Rainmeter illustro / ModernGadgets** | 双列信息表、环形进度条（MeterRoundLine）、折线历史（MeterLine）、点阵/电平、番茄式条件变色 | `DualColumnView`、`RingGaugeView`、`SparklineView`、`DotMatrixView` |
| **Windows 11 小组件 / Fluent Design** | 卡片网格、圆角、玻璃拟态、高光描边、亮暗跟随系统 | `CardGridView`、`GlassPanelView`、`FluentWin11` 主题 |
| **macOS 小组件 / iStat Menus** | 半透明玻璃卡片、大数值 + 细进度条、极简纯文本贴壁纸 | `GlassPanelView`、`MinimalTextView` |
| **btop / htop / 运维大屏** | 等宽 ASCII 条形图、扫描线、LIVE 状态栏、深色终端配色 | `HudTerminalView`、`MatrixTerminal` 主题 |
| **HWiNFO / LibreHardwareMonitor** | 传感器缺失时降级、无管理员权限只读可用项 | `Compatibility`、`HardwareGracefulDegradation` |
| **HWLineChart** | 每项一条 64 点实时趋势曲线 | `UltraHistory` + `SparklineView` |
| **今日热榜 tophub.today** | 多榜单聚合、排名/热度/来源、每日归档 | `AiNewsService`、`AiNewsForm`、`NewsTickerView` |
| **股票行情跑马灯 / RSS Ticker / iStat Menus 菜单栏** | 单行横向滚动、指标与资讯同排、点击直达原文、亮/暗双配色、暂停与下一条 | `TaskbarNewsCast`、`UltraNewsStrip`、`InfoBarView` |
| **WinForms 高 DPI 最佳实践** | Per-Monitor V2、AutoScaleMode.Dpi、按屏幕 DPI 重算、工作区 clamp | csproj `ApplicationHighDpiMode`、`Compatibility` |

设计原则：**渲染与数据解耦、新旧完全隔离、失败一律降级**。所有新增代码都在 `src/Ultra/` 下，
上游只改 7 处（其中任务栏窗口 2 处为新增播报区），随时可以把 Ultra 目录整包摘掉回到原版。

---

## 2. 架构

```
Program.Main
  ├─ UltraConfig.Load()                     ← 独立配置，损坏自动备份重建
  └─ MainForm 构造
       ├─ UIController (上游)               ← 每 Tick 更新 MetricItem 数值
       ├─ UltraRuntime.Initialize()         ← ★ 唯一总入口
       │    ├─ Compatibility.Initialize()   兼容自检 → data/compat-report.txt
       │    ├─ UltraThemeManager            内置 10 套主题 + 字体回退 + 亮暗跟随
       │    ├─ ViewEngine.RegisterDefaults  注册 11 个 IUltraView
       │    ├─ AiNewsService.Start()        每日 09:00 + 每 6h + 启动补抓
       │    ├─ SetupHotkeys()               RegisterHotKey × 6
       │    ├─ SetupHousekeeping()          主题跟随 / 视图轮播 / 跑马灯重绘
       │    └─ _cast Timer (220ms / Eco 700ms)  资讯播报滚动重绘
       └─ MenuManager.Build() → UltraMenu.Inject()  ← 注入顶级菜单

TaskbarForm.Tick / OnPaint
  ├─ Width = 指标区 + TaskbarNewsCast.DesiredWidth(DPI)
  ├─ TaskbarRenderer.Render() 画原有两行指标
  └─ TaskbarNewsCast.Render() 画右侧 AI 热榜播报（亮暗/自定义配色同步）
       └─ 单击原文 / Ctrl+单击下一条 / Shift+单击暂停 / 双击全部

MainForm.OnPaint → UIController.Render()
  └─ UltraRuntime.Render(g, form, groups, cols, theme)
       ├─ ViewMode == Classic / 引擎异常 → return false → 原版 UIRenderer / HorizontalRenderer
       └─ 否则
            ├─ BuildContext()   MetricItem → UltraMetric 快照 + 历史 + 新闻
            ├─ view.Measure()   计算客户区尺寸（含 DPI × 用户缩放）
            ├─ ClientSize 不同 → 调整窗口，下一帧重绘（避免 GDI 裁剪错位）
            └─ view.Render()    GDI+ 自绘
```

### 新增文件清单

| 文件 | 职责 |
|---|---|
| `src/Ultra/Core/UltraConfig.cs` | 独立配置 + 版本迁移 + 原子写入 + 损坏备份 |
| `src/Ultra/Core/UltraTheme.cs` | Ultra 主题模型（渐变/发光/强调色/字体链）+ 10 套内置主题 + 管理器 |
| `src/Ultra/Core/UltraRuntime.cs` | 运行时总控：渲染分派、视图/主题切换、热键、窗口、新闻调度、热榜导航 |
| `src/Ultra/Core/UltraLog.cs` | 异常隔离 `Guard` + 双日志（错误/事件） |
| `src/Ultra/Compat/Compatibility.cs` | DPI/多屏/OS/权限/电池/虚拟机/性能档/字体回退 |
| `src/Ultra/Views/ViewModels.cs` | `IUltraView`、`UltraRenderContext`、`UltraMetric`、`UltraHistory`、`UltraGfx` |
| `src/Ultra/Views/Views_1.cs` | 紧凑单条 / 双列信息表 / 极简纯文本 / 点阵电平 |
| `src/Ultra/Views/Views_2.cs` | 卡片网格 / 环形仪表 / 迷你折线 / 终端 HUD |
| `src/Ultra/Views/Views_3.cs` | 玻璃拟态 / AI 热榜跑马灯 |
| `src/Ultra/Views/Views_4.cs` | `UltraNewsStrip` 通用播报条 + 资讯播报条 `InfoBarView` |
| `src/Ultra/News/TaskbarNewsCast.cs` | 任务栏播报引擎：轮播、横向滚动、命中区、点击/暂停/下一条、配色 |
| `src/Ultra/Tools/UltraPreview.cs` | 内置 `--ultra-preview` 离屏渲染自检，导出全部 UI 与播报预览图 |
| `src/Ultra/News/AiNewsService.cs` | 抓取、HTML 解析、按日归档、定时调度、离线回退、导出 |
| `src/Ultra/News/AiNewsForm.cs` | 热榜浏览窗口（搜索/筛选/日期/打开原文/MD·CSV·TXT 导出） |
| `src/Ultra/News/HotListData.cs` | 内置 214 个热榜聚合站点数据（JSON 常量 + 解析，无需外部文件） |
| `src/Ultra/UI/HotListNavigatorForm.cs` | 热榜导航窗口（搜索 / 分组筛选 / 卡片 / 打开原文 / 复制链接，暗色主题） |
| `src/Ultra/UI/UltraAboutForm.cs` | 关于窗口：展示原作者 Diorser 与二次开发者 t84RT 信息，可点击链接 / 复制署名 |
| `src/Ultra/Tools/UltraToolsCore.cs` | 系统摘要/进程/磁盘/网络/文本/截图取色/备份/快捷启动 |
| `src/Ultra/Tools/UltraToolsForm.cs` | 8 分页工具箱 UI |
| `src/Ultra/UI/UltraMenu.cs` | 托盘/右键菜单注入 |
| `src/Ultra/UI/UltraSettingsForm.cs` | 4 分页 Ultra 设置窗口 |
| `resources/ultra_themes/*.json` | 10 套主题（可直接编辑/复制扩展） |
| `ULTRA_README.md` / `使用说明(必读).txt` / `build-ultra.bat` | 文档与构建 |

### 上游仅 7 处改动

| 文件 | 改动 |
|---|---|
| `LiteMonitor.csproj` | `ApplicationHighDpiMode=PerMonitorV2`、复制 ultra_themes、`Product` 标识 |
| `src/System/Program.cs` | 提前加载 `UltraConfig`、跳过 PawnIO 驱动硬阻塞、finally 兜底清理 |
| `src/UI/UIController.cs` | `Render()` 首行分派 `UltraRuntime.Render()` |
| `src/UI/MainForm_Transparent.cs` | 初始化 Ultra、`WM_HOTKEY` 处理、关闭时 Shutdown |
| `src/UI/MenuManager.cs` | `return menu` 前 `UltraMenu.Inject()` |
| `src/UI/TaskbarForm.cs` | 窗口宽度/高度容纳播报区、绘制、单击/双击、独立高频重绘定时器 |
| `src/UI/TaskbarRenderer.cs` | 暴露 `CurrentFont` 与 `GetPalette()`，让播报与指标同字体同配色 |
| `src/System/Program.cs` | 另加 `--ultra-preview` 无窗体自检命令（不检查单实例/不装驱动） |

---

## 3. UI 形态（12 种，运行时即时切换）

| # | 形态 | 尺寸策略 | 适用场景 |
|---|---|---|---|
| 0 | 经典原版（竖排 / 横条） | 上游 `UILayout` / `HorizontalLayout` | 想继续用原版主题编辑器 |
| 1 | 紧凑单条 | 按文本测量自适应宽度 | 贴屏幕顶部 / 任务栏上方 |
| 2 | 双列信息表 | 两列 × 行高，密度最高 | 监控项多、需要长期盯 |
| 3 | 卡片网格（默认） | 2 列卡片，4K 与小屏等比缩放 | 通用桌面 |
| 4 | 环形仪表盘 | 每行最多 4 环 | 游戏桌面 / 副屏 |
| 5 | 迷你折线图 | 每项 64 点历史曲线 | 观察趋势、排查卡顿 |
| 6 | 终端 HUD | 等宽 ASCII 条 + 扫描线 | 运维 / 极客 |
| 7 | 玻璃拟态 | 半透明卡片 + 高光 | 浅色壁纸 / Win11 |
| 8 | 点阵电平 | 16 段 LED | 低配机器（零渐变零动画） |
| 9 | AI 热榜 + 监控 | 顶部 3 指标 + 新闻轮播 | 想边看监控边刷 AI 新闻 |
| 10 | 极简纯文本 | 单行，近透明 | 贴壁纸、几乎不占视觉 |
| 11 | 资讯播报条 | 两行紧凑指标 + 底部新闻滚动，按文本动态定宽 | 想在悬浮条里同时看指标与 AI 热榜 |

切换后无需重启；`UltraRuntime.Apply()` 会重建布局、刷新菜单、重设透明度并重绘。
可开启「自动轮播」每 N 秒轮换所有形态（用于展示/挑皮肤）。

### 扩展第 13 种形态

1. 在 `UltraViewMode` 枚举加一个值；
2. 新建类实现 `IUltraView`（`Id / Name / Description / Measure / Render`）；
3. 在 `ViewEngine.RegisterDefaults()` 里 `Register(new XxxView())`；
4. 用 `UltraGfx` 的 `Background / Card / Bar / Ring / Sparkline / Text / WithAlpha` 画即可。

`Measure()` 返回期望客户区尺寸，`Render()` 只管画。所有缩放统一走 `c.S(px)`，
所有颜色走 `c.Theme`，三色报警走 `c.LevelColor(m)` —— 新视图自动继承全部主题与兼容策略。

---

## 4. Ultra 主题系统

主题文件：`resources/ultra_themes/<Name>.json`，修改后切换一次即生效。
程序启动时若目录为空会自动写入 10 套内置主题（**任何电脑开箱可用**）。

| 字段组 | 字段 |
|---|---|
| 背景 | `Background`、`BackgroundEnd`、`Gradient`、`GradientAngle` |
| 卡片 | `Card`、`CardBorder`、`CornerRadius`、`Padding`、`Gap`、`RowHeight` |
| 文字 | `Text`、`TextDim`、`FontFamily`、`ValueFontFamily`、`FontSize`、`ValueFontSize`、`BoldValues` |
| 强调 | `Accent`、`Accent2`、`Safe`、`Warn`、`Crit`、`BarTrack`、`Divider` |
| 特效 | `GlowStrength`、`RoundedBars`、`ShowGridLines`、`IsDark` |

内置：`MidnightGlass`、`CyberNeon`、`PaperLight`、`Aurora`、`SolarAmber`、
`MatrixTerminal`、`OceanDeep`、`Sakura`、`GraphiteMono`、`FluentWin11`。

三种切换模式：**固定** / **跟随系统亮暗**（读注册表 `AppsUseLightTheme`）/ **按时间自动**（默认 19:00 转暗、07:00 转亮）。
字体用 `FontResolver` 校验已安装字体，缺失时按 CJK / 等宽两条链回退，避免精简版 Windows 上 `new Font` 抛异常。

> 原版 `resources/themes/*.json` 10 套主题完全保留，`Classic` 视图继续使用，主题编辑器照常可用。

---

## 5. 每日 AI 新闻（tophub.today/c/ai）

### 5.1 抓取与解析

- `HttpClient` + 浏览器 UA + gzip/deflate/brotli 自动解压，25s 超时，每个 URL 重试 2 次；
- 候选 URL：主页 → `?order=ID` → http 回退（应对国内 TLS 抖动）；
- 页面 DOM 规则（实测 2026-11-12，12 个榜单 / 225 条目）：

```html
<div class="cc-cd" id="node-98">
  <div class="cc-cd-lb">掘金</div>                       <!-- 榜单来源 -->
  <span class="cc-cd-sb-st">人工智能本周最热</span>       <!-- 栏目 -->
  <a href="https://juejin.cn/post/...">
    <div class="cc-cd-cb-ll">
      <span class="s h">1</span>                         <!-- 排名 -->
      <span class="t">阿里版Codex…</span>                 <!-- 标题 -->
      <span class="e">4320</span>                        <!-- 热度 -->
    </div>
  </a>
</div>
```

对应 `ReBlock` / `ReBoard` / `ReColumn` / `ReEntry` 四个正则 + HTML 解码去标签。
实测解析结果：**12 个榜单，按每榜 10 条共 120 条**（可在设置里调每榜 1~50、榜单 1~30）。

### 5.2 调度与容错

| 行为 | 默认 |
|---|---|
| 每日固定抓取 | 09:00（可设任意 HH:MM） |
| 额外间隔补抓 | 每 6 小时（0 = 关闭） |
| 启动补抓 | 当日无缓存时自动抓 |
| 缓存 | `data/ai_news/YYYY-MM-DD.json`，保留 30 天，自动清理 |
| 离线 / 页面改版 | 自动回退到最近一次缓存，状态显示「抓取失败 · 使用本地缓存」，不弹错 |
| 完成提醒 | 托盘气泡（可关） |
| 异常 | `ultra_error.log` 记录，监控主流程完全不受影响 |

`NextFetch` 由固定时刻 + 间隔两个条件取较早者，每次抓取成功后重算。
`AiNewsForm` 支持搜索、按来源/日期筛选、关键词高亮、双击打开原文、复制标题/链接、
导出 Markdown / CSV / TXT、打开缓存目录、一键跳到抓取设置。
`NewsTickerView` 把热榜标题按 `AiNewsTickerSeconds` 轮播进悬浮面板，并显示来源、热度、抓取时间与轮播进度点。

### 5.3 导航栏 / 任务栏播报（本次新增重点）

抓取到的每日信息不止能弹窗查看，还会**直接在任务栏那一条监控栏里滚动播报**：

```
[CPU 31.2%  GPU 4.65%  ▲0.15KB ] [1] [掘金] AI 正在蚕食我们的编码能力
[CPU 64.0°C 内存 11.5GB ▼6.46KB]     1/40 · 第 1 名 · 热度 2031 · 11-12 09:56
                                     ────────── 轮播进度线 ──────────
```

实现要点：

| 能力 | 说明 |
|---|---|
| 原生任务栏 | `TaskbarForm` 窗口宽度 = 指标区 + 播报区，`UpdatePlacement` 自动往左让位；Layered 透明窗口只画不透明文字/色块，不铺背景，避免与 `TransparentKey` 混色 |
| 配色一致 | `TaskbarRenderer.GetPalette()` 让播报与指标共用亮/暗或用户自定义颜色；复用 `CurrentFont` 字体 |
| 轮播与滚动 | 按 `TaskbarNewsSeconds` 轮播，长标题在停留周期内匀速横向滚动；滚动文字先画到透明离屏层再 `DrawImage` 合成，保证 GDI+ 裁剪严格生效 |
| 交互 | 单击打开原文 · `Ctrl+单击` 下一条 · `Shift+单击` 暂停/继续 · 双击打开完整热榜窗口 · 无数据时单击立即抓取 |
| 过滤 | 可按来源只播报指定榜单；`AiNewsKeywords` 命中的条目优先播报；最多播报条数可配 |
| 垂直任务栏 | 播报区追加在指标下方（高度 `TaskbarNewsHeight`），不破坏 Win10/Win11 定位策略 |
| 悬浮面板 | 新增 `InfoBarView` 资讯播报条（两行紧凑指标 + 新闻滚动）；也可开 `PanelNewsOverlay`，在任意视图底部叠加一行播报 |
| 性能 | 独立 `_newsTimer`：High 档 120ms、Eco 档 400ms，只 `Invalidate` 不重算布局；主面板播报由 `_cast` 220/700ms 驱动 |
| 降级 | 抓不到数据/缓存为空时显示可点击的「暂无数据 · 点击立即抓取」，绝不出现空白；开关 `Ctrl+Alt+B` 一键还原纯指标 |

菜单：`★ Ultra 增强 → AI 每日热榜 → 导航栏资讯播报`，可开关、调宽度/秒数/来源、下一条/暂停。
设置窗口 `③ 新闻与工具` 下半部分为播报完整参数。

### 5.4 热榜导航（内置 214 个同类聚合站点）

除了 tophub 的 AI 热榜抓取，**还把一份「今日热榜」同类站点清单（214 个聚合站）直接内置进软件**，
做成一个可离线打开的导航窗口。数据来自交付时的快照（见 `今日热榜同类站点清单.{html,md}`），
解析后存为 `src/Ultra/News/HotListData.cs` 里的 JSON 常量，**无需任何外部文件即可使用**。

分组：A 综合热榜（86）、B 科技/数码（19）、C 社区/论坛/垂直（60）、D 视频/娱乐（27）、E 海外/其他（22）。

窗口能力（`HotListNavigatorForm`）：

| 能力 | 说明 |
|---|---|
| 暗色主题 | 与 Ultra 悬浮窗一致的深蓝玻璃风（`#16222A` 背景），独立窗口、不抢占监控焦点 |
| 搜索 | 按站点名 / 域名 / 备注实时过滤，空输入显示全部 |
| 分组筛选 | 顶部 6 个按钮：全部 / A / B / C / D / E，一键只看某类站点 |
| 卡片 | 每张卡含站点名（可点击打开）、分组徽标、域名、两行备注、探测状态（可访问/超时/未知） |
| 打开原文 | 站点名即 `LinkLabel`，单击用默认浏览器打开该站首页（`Process.Start` + `UseShellExecute`） |
| 复制链接 | 每张卡右下角「复制」按钮，点击复制首页 URL，2 秒后按钮文字自动复原 |
| 统计 | 顶部显示「共 N 个站点 · 当前显示 M 个」 |

入口：

- 菜单：`★ Ultra 增强 → 热榜导航  Ctrl+Alt+H`（也在「工具箱」子菜单下，标注「热榜导航 (214 站点)」）
- 热键：`Ctrl+Alt+H` 直接打开

> 该清单是静态快照（截至 2026-11-12 探测），站点可用性随网络与站点本身变化；状态列仅供参考。
> 若需更新，替换 `HotListData.cs` 里的 `Json` 常量并重新编译即可。

### 5.5 作者信息与署名（关于窗口）

为明确「二次开发」来源，新增独立「关于」窗口，完整展示两方署名：

- **原作者（上游）**：Diorser —— [github.com/Diorser/LiteMonitor](https://github.com/Diorser/LiteMonitor)，轻量可定制的开源桌面硬件监控。
- **二次开发者（本项目）**：小吴同学电气设计（`t84RT`）
  - GitHub：[github.com/t84RT](https://github.com/t84RT)
  - 个人主页：[t84RT.github.io](https://t84RT.github.io)
  - 博客园：[Student-Wu-s-Electrical-Design-t84RT](https://www.cnblogs.com/Student-Wu-s-Electrical-Design-t84RT)
  - 邮箱：xiaowu112899@outlook.com
  - 简介：用代码与算法重塑传统电气设计流程，专注工控/PLC/伺服/配电设计，并探索嵌入式 IoT 与效率工具（C#/Python/浏览器扩展）。

窗口能力（`UltraAboutForm`）：

| 能力 | 说明 |
|---|---|
| 双署名卡片 | 原作者与二次开发者分块展示，含简介与可点击链接（GitHub / 主页 / 博客园 / 邮箱） |
| 开源协议 | 标注 MIT（继承原作者 Diorser），提醒保留双方署名 |
| 复制我的信息 | 一键把二次开发者联系方式复制到剪贴板 |
| 启动提示 | 首次启动以气泡提示二次开发署名（仅一次，由 `UltraConfig.SeenAboutTip` 控制） |

入口：

- 菜单：`★ Ultra 增强 → 关于 LiteMonitor.Ultra  (作者信息)  Ctrl+Alt+A`
- 热键：`Ctrl+Alt+A` 直接打开

---

## 6. 工具箱（8 分页）

| 页 | 内容 |
|---|---|
| ① 系统概览 / 快捷动作 | OS/架构/CPU/内存/权限/电池/虚拟机/显示器/DPI/性能档自检 + 上游 12 个功能入口（内存清理、硬件详情、历史曲线、流量统计、网络测速、主题编辑器、原版设置、任务管理器、系统信息、资源监视器、DirectX 诊断、事件查看器） |
| ② 进程 TOP | 两次采样算 CPU%、内存排序、结束进程 |
| ③ 磁盘 / 网络 | 各盘容量与占用、网卡/IP/流量，`ipconfig /all`、`ping`、`/flushdns`、`route print`、`netstat` |
| ④ 文本 / 编码 | MD5/SHA1/SHA256、Base64、URL、大小写、去重/排序、JSON 美化压缩、时间戳互转、UUID、强密码、字数统计、文件 SHA256 |
| ⑤ 截图 / 取色 | 主屏 / 所有屏幕截图、实时取色（HEX/RGB/HSL，一键复制） |
| ⑥ 快捷启动 | 自定义程序清单，持久化到 `ultra.json` |
| ⑦ 番茄钟 | 1~180 分钟，托盘气泡提醒 |
| ⑧ 备份 / 诊断 | 配置整包 zip 备份与还原、错误日志、事件日志、兼容性自检报告 |

---

## 7. 适配更多电脑：兼容性矩阵

| 场景 | 处理 |
|---|---|
| 100% / 125% / 150% / 200% 缩放 | 项目级 `PerMonitorV2` + `GetDpiForWindow` + `Screen.DeviceDpi` 三重回退，缩放钳制 0.5~3.0 |
| 多显示器不同 DPI | 按窗口所在屏幕实时取 DPI，`OnDpiChanged` 重建主题字体与布局 |
| 拔掉副屏 / 分辨率变化 / 旋转 | `ClampToWorkArea` 把窗口拉回有效工作区，按 `设备名\|分辨率` 指纹记忆位置 |
| 1366×768 小屏 / 4K 大屏 | `ViewBase.Fit` 限制最大不超过工作区 92% × 88%，布局自动折列 |
| 精简版 / 英文 / 日文 Windows 缺字体 | `FontResolver` 校验 `InstalledFontCollection`，CJK 与等宽双回退链 |
| 无独显 / 无电池 / 无传感器 | `HardwareGracefulDegradation` 隐藏无读数项，显示 `--`，不弹异常 |
| 无管理员权限 | 传感器不可用自动降级；新增 `SkipDriverPrompt` 跳过原版 PawnIO 驱动强制安装（默认开） |
| 虚拟机 / 双核 / 2GB 内存 | 自动 `Eco` 档：提高刷新间隔、关闭渐变/发光/动画 |
| 笔记本电池供电 | 自动关闭特效、降低刷新 |
| Win10 / Win11 任务栏差异 | 沿用上游 `TaskbarStrategyWin10/11`，Ultra 视图不改动任务栏逻辑 |
| 配置损坏 / 目录只读 | `ultra.json` 自动备份为 `.broken.*` 并重建；所有写操作 try/catch |
| 程序目录在 `Program Files` 不可写 | 自检报告标红「配置可写：否」，提示移到非系统目录 |
| 新增功能自身异常 | `UltraLog.Guard` 全部隔离，写日志后降级回原版渲染，绝不拖垮监控 |

自检报告输出：`data/compat-report.txt`，可在工具箱第 ⑧ 页直接查看。

---

## 8. 配置字段（`ultra.json`，独立于原版 `settings.json`）

| 分组 | 关键字段 |
|---|---|
| 视图 | `ViewMode`、`UiScale`、`MaxMetrics`、`ShowTitle`、`ShowBars`、`SmoothAnimation`、`AutoCycleViews`、`AutoCycleSeconds` |
| 主题 | `UltraTheme`、`LightTheme`、`ThemeMode`、`ScheduledDarkHour/LightHour`、`AccentByLoad`、`PanelOpacity` |
| 兼容 | `PerfTier`、`PerMonitorDpi`、`ClampToWorkArea`、`SafeFontFallback`、`HardwareGracefulDegradation`、`DisableAnimationsOnBattery`、`SkipDriverPrompt`、`PreferredMonitorDevice`、`RememberPerMonitorPosition` |
| 播报 | `TaskbarNewsEnabled`、`TaskbarNewsWidth/Height/Seconds`、`TaskbarNewsScroll`、`TaskbarNewsShowRank/Board`、`TaskbarNewsClickToOpen`、`TaskbarNewsMaxItems`、`TaskbarNewsBoardFilter`、`PanelNewsOverlay` |
| 新闻 | `AiNewsEnabled`、`AiNewsUrl`、`AiNewsFetchAt`、`AiNewsRefreshHours`、`AiNewsFetchOnStartup`、`AiNewsNotify`、`AiNewsMaxPerBoard/Boards`、`AiNewsKeepDays`、`AiNewsKeywords`、`AiNewsTickerSeconds` |
| 工具 | `QuickLaunch`、`PomodoroMinutes`、`HotkeysEnabled` |

版本化 `SchemaVersion=4`（v4 起支持任务栏播报），`Migrate()` 补齐旧版字段并钳制数值边界；保存采用「临时文件 → 备份 → 原子替换」。

---

## 9. 构建与发布

环境：Windows 10/11 + .NET 8 SDK（本机 .NET 10 SDK 亦可，运行时需 .NET 8 Desktop Runtime）。

```bat
dotnet restore LiteMonitor.csproj
dotnet build LiteMonitor.csproj -c Release
dotnet publish LiteMonitor.csproj -c Release -r win-x64 --self-contained false
```

**自带渲染自检**（不启动窗体、可在无桌面会话运行，用于确认所有 UI 与播报渲染正常）：

```bat
dotnet LiteMonitor.dll --ultra-preview UI预览
:: 或运行源码包里的 preview-tool（反射加载交付程序集，规避部分系统的应用控制策略）
dotnet preview-tool/bin/Release/net8.0-windows/UltraViewPreview.dll UI预览
```

输出目录 `bin/Release/net8.0-windows/` 需包含：
`LiteMonitor.exe`、`LiteMonitor.dll`、`*.json` 依赖清单、
`resources/themes/`（原版 10 套）、`resources/ultra_themes/`（Ultra 10 套）、
`resources/lang/`（9 语言）、`resources/plugins/`、`resources/assets/`。

运行时会自动生成：`ultra.json`、`ultra.json.bak`、`data/ai_news/`、`data/screenshots/`、
`data/backups/`、`data/compat-report.txt`、`data/ultra_events.log`、`ultra_error.log`。

---

## 10. 验证记录

| 项目 | 结果 |
|---|---|
| 源码获取 | `codeload.github.com/Diorser/LiteMonitor/zip/refs/heads/master`（8.0 MB，master 分支；`main` 为 404） |
| 基线构建 | 上游原样构建有 1 个错误（缺 `使用说明(必读).txt`），已补齐 |
| Ultra 构建 | `dotnet build -c Release` → **0 错误**，产物 `LiteMonitor.exe` 186,880 字节 |
| 主题产物 | 输出目录含 10 个 `ultra_themes/*.json` |
| 新闻解析 | 真实页面 HTML 复现同一套正则 → 12 个榜单 / 120 条；C# 实跑抓取 → **120 条 / 11 个不同来源**，`data/ai_news/2026-11-12.json` 56 KB |
| 启动实测 | `Windows 11 Pro build 26200`、DPI 120(125%)、8 核 / 16 GB、High 性能档、字体回退正常；自动跟随系统浅色加载 `PaperLight`，缩放 1.25 |
| 配置落盘 | 首次启动生成 `ultra.json`（44 个字段）与 `data/compat-report.txt` |
| UI 渲染 | 通过程序内置 `--ultra-preview`（由 `preview-tool` 反射加载交付程序集触发）离屏 GDI+ 调用全部 11 个 `IUltraView.Render()` → **11/11 成功**，另渲染亮/暗任务栏播报与面板叠加播报，共 14 张 `UI预览/*.png` + 总览图 |
| 异常日志 | 实跑后 `ultra_error.log` 无 ERROR/WARN 记录 |
| 导航栏播报 | `dotnet LiteMonitor.dll --ultra-preview UI预览` 自检：`11/11` 种视图 + 亮/暗任务栏播报 + 面板叠加播报全部渲染成功；真实缓存 120 条，播报引擎 `enabled=True / items=40 / 125% DPI = 375px / 8s` |
| 配置迁移 | 成品 `ultra.json` 由 v3（44 字段）平滑升级到 v4（55 字段），旧值全部保留，播报默认开启 |
| 裁切修复 | 放大 3 倍逐张检查，修掉长标题滚动越过右侧计数区（改为离屏文字层 + GDI+ 合成，裁剪严格生效）与亮色次要文字对比度 |
| 显示不全二次修复 | 针对用户截图反馈再次复检：`UltraGfx.Text` 增加字号自适应（测量高度超出格子时按 0.98 比例缩字，根治 125% DPI 下 `GraphicsUnit.Point` 字体比 18px 框高导致的上下裁切）；`RingGauge` 中心值同时受内直径与中心高度双重约束，环形盘内数值不再溢出/重叠；`DualColumn` 列宽 + 标签占比调整并加 `Ellipsis`；`HudTerminal` 标题与时钟分框；`NewsTicker` 三指标卡改为「标签在上、数值在下、数值占满卡宽」，长值（如 `9.8/16 GB`）不再被压成 `9…`。离屏自检 14 张图逐张复核：环形/双列/迷你折线/终端 HUD/资讯条/AI 热榜卡均无裁切重叠 |
| 热榜导航 | 新增 `HotListNavigatorForm` + `HotListData`（214 站点 JSON 常量）；菜单「★ Ultra 增强 → 热榜导航  Ctrl+Alt+H」与「工具箱 → 热榜导航 (214 站点)」双入口，热键 `Ctrl+Alt+H`；支持搜索/分组筛选 A-E/卡片打开原文/复制链接；编译 0 错误，预览自检通过 |
| 作者署名 / 关于 | 新增 `UltraAboutForm`：展示原作者 Diorser 与二次开发者 t84RT（GitHub/主页/博客园/邮箱可点击）；新增热键 `Ctrl+Alt+A` 与菜单「关于 LiteMonitor.Ultra (作者信息)」；首次启动气泡提示二次开发署名（一次性）；仓库根 `README.md` 改写为本项目说明并保留 `README.upstream.md` 上游原文档 |

---

## 11. 已知边界与后续可扩展点

- 新闻解析依赖 tophub 页面结构；若站点改版，`ReEntry` 需同步调整。已内置「解析到 0 条即回退缓存 + 写日志」保护。
- `RingGaugeView` 每行最多 4 环，指标过多时自动折行，窗口会变高。
- 任务栏嵌入复用上游 `TaskbarForm`；Ultra 的 12 种形态作用于桌面悬浮面板，任务栏窗口则在其右侧追加一列资讯播报（垂直任务栏追加在底部）。若要把任意 Ultra 形态整体嵌入任务栏，可在 `TaskbarRenderer` 里调用 `IUltraView.Render` 并传入任务栏尺寸的 context。
- 主题仅支持颜色/字体/圆角等参数化字段；若要背景图片/毛玻璃 Blur，可在 `UltraGfx.Background` 增加位图绘制分支。
- 全局热键固定 7 组（V/T/U/N/B/H/A），若与其他软件冲突可在 `UltraRuntime.RegisterAll` 改键或关闭 `HotkeysEnabled`。

---

## 12. 许可

基于 **Diorser/LiteMonitor（MIT License）** 修改，保留原作者署名。
Ultra 新增代码同样按 MIT 许可发布，详见 `LICENSE`。
